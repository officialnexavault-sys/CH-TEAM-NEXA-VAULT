import { useState, useEffect, useRef } from 'react';

// ─── Icons ────────────────────────────────────────────────────────────────────

const IconShield = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-5 h-5">
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.955 11.955 0 003 12c0 6.627 5.373 12 12 12s12-5.373 12-12c0-2.128-.556-4.124-1.534-5.855M12 2.25c.657 0 1.302.055 1.93.162" />
  </svg>
);

const IconLock = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-5 h-5">
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
  </svg>
);

const IconGlobe = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-5 h-5">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418" />
  </svg>
);

const IconBolt = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-5 h-5">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" />
  </svg>
);

const IconSupport = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-5 h-5">
    <path strokeLinecap="round" strokeLinejoin="round" d="M8.625 12a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H8.25m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 01-2.555-.337A5.972 5.972 0 015.41 20.97a5.969 5.969 0 01-.474-.065 4.48 4.48 0 00.978-2.025c.09-.457-.133-.901-.467-1.226C3.93 16.178 3 14.189 3 12c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25z" />
  </svg>
);

// Unused but reserved for future sections
// const IconCommunity = ...
// const IconStar = ...

const IconArrow = () => (
  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
  </svg>
);

const IconX = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.737-8.835L1.254 2.25H8.08l4.261 5.632 5.903-5.632zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
  </svg>
);

const IconDiscord = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057.1 18.079.11 18.1.12 18.12a19.91 19.91 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
  </svg>
);

const IconTelegram = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
    <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
  </svg>
);

const IconYoutube = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
    <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
  </svg>
);

const IconMail = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-5 h-5">
    <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" />
  </svg>
);

// ─── Data ────────────────────────────────────────────────────────────────────

const TRUST_BADGES = [
  { icon: <IconShield />, label: 'SSL Secured', sub: '256-bit Encryption', color: 'text-emerald-400', glow: 'rgba(16,185,129,0.15)' },
  { icon: <IconLock />, label: 'PCI DSS', sub: 'Level 1 Compliant', color: 'text-violet-400', glow: 'rgba(124,58,237,0.15)' },
  { icon: <IconGlobe />, label: 'Global CDN', sub: '99.9% Uptime SLA', color: 'text-cyan-400', glow: 'rgba(34,211,238,0.15)' },
  { icon: <IconBolt />, label: 'Instant Delivery', sub: 'Sub-60 Second TX', color: 'text-amber-400', glow: 'rgba(251,191,36,0.15)' },
];

const PLATFORM_LINKS = [
  { label: 'Top-Up Games', badge: null },
  { label: 'Digital Gift Cards', badge: null },
  { label: 'NEXA Rewards', badge: 'NEW' },
  { label: 'Vault Balance', badge: null },
  { label: 'Transaction History', badge: null },
  { label: 'Referral Program', badge: null },
];

const SUPPORT_LINKS = [
  { label: 'Help Center', badge: null },
  { label: 'Live Chat Support', badge: '24/7' },
  { label: 'Order Tracking', badge: null },
  { label: 'Report an Issue', badge: null },
  { label: 'Dispute Resolution', badge: null },
  { label: 'Account Security', badge: null },
];

const COMPANY_LINKS = [
  { label: 'About NEXA-VAULT', badge: null },
  { label: 'Platform Roadmap', badge: null },
  { label: 'Press & Media', badge: null },
  { label: 'Careers', badge: 'HIRING' },
  { label: 'Partner With Us', badge: null },
  { label: 'Developer API', badge: 'BETA' },
];

const LEGAL_LINKS = [
  'Privacy Policy',
  'Terms of Service',
  'Cookie Policy',
  'AML Policy',
  'Refund Policy',
];

const PAYMENT_METHODS = ['Visa', 'Mastercard', 'PayPal', 'Crypto', 'Apple Pay', 'Google Pay'];

const SOCIAL_LINKS = [
  { icon: <IconX />, label: 'X / Twitter', handle: '@nexavault', color: '#e2e8f0' },
  { icon: <IconDiscord />, label: 'Discord', handle: '180K Members', color: '#5865f2' },
  { icon: <IconTelegram />, label: 'Telegram', handle: 'Channel', color: '#229ed9' },
  { icon: <IconYoutube />, label: 'YouTube', handle: 'Content', color: '#ff0000' },
];

// ─── Sub-components ──────────────────────────────────────────────────────────

function FooterLink({ label, badge }: { label: string; badge?: string | null }) {
  return (
    <li>
      <a
        href="#"
        className="group flex items-center gap-2 text-slate-500 hover:text-slate-200 transition-all duration-200 text-sm py-1"
        onClick={(e) => e.preventDefault()}
      >
        <span className="w-0 group-hover:w-3 h-px bg-violet-400 transition-all duration-300 flex-shrink-0" />
        <span className="group-hover:translate-x-0.5 transition-transform duration-200">{label}</span>
        {badge && (
          <span className={`ml-1 text-[9px] font-bold px-1.5 py-0.5 rounded-full tracking-wider
            ${badge === 'NEW' ? 'bg-violet-500/20 text-violet-300 border border-violet-500/30' : ''}
            ${badge === '24/7' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : ''}
            ${badge === 'HIRING' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : ''}
            ${badge === 'BETA' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : ''}
          `}>
            {badge}
          </span>
        )}
      </a>
    </li>
  );
}

function TrustBadge({ icon, label, sub, color, glow }: typeof TRUST_BADGES[0]) {
  return (
    <div
      className="group flex items-center gap-3 px-4 py-3.5 rounded-xl border border-white/5 transition-all duration-300 cursor-default"
      style={{ background: `radial-gradient(circle at 30% 50%, ${glow} 0%, transparent 70%)` }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLDivElement).style.borderColor = glow.replace('0.15', '0.4');
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLDivElement).style.borderColor = 'rgba(255,255,255,0.05)';
      }}
    >
      <div className={`${color} flex-shrink-0 group-hover:scale-110 transition-transform duration-300`}>
        {icon}
      </div>
      <div>
        <div className="text-xs font-semibold text-slate-200">{label}</div>
        <div className="text-[10px] text-slate-500">{sub}</div>
      </div>
    </div>
  );
}

// ─── Main Footer ─────────────────────────────────────────────────────────────

export default function Footer() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const footerRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setIsVisible(true); },
      { threshold: 0.05 }
    );
    if (footerRef.current) observer.observe(footerRef.current);
    return () => observer.disconnect();
  }, []);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) { setSubscribed(true); setEmail(''); }
  };

  return (
    <>
      {/* ─── Atmospheric transition zone ─── */}
      <div className="relative h-40 pointer-events-none overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#080612]" />
        {/* Floating particles */}
        {[...Array(6)].map((_, i) => (
          <div
            key={i}
            className="absolute w-0.5 h-0.5 rounded-full bg-violet-400/60 animate-float-slow"
            style={{
              left: `${15 + i * 14}%`,
              top: `${20 + (i % 3) * 25}%`,
              animationDelay: `${i * 0.8}s`,
              animationDuration: `${5 + i}s`,
            }}
          />
        ))}
        {/* Horizontal glowing line */}
        <div className="absolute bottom-0 left-0 right-0 h-px"
          style={{ background: 'linear-gradient(90deg, transparent 0%, rgba(124,58,237,0.5) 20%, rgba(167,139,250,0.8) 50%, rgba(124,58,237,0.5) 80%, transparent 100%)' }} />
      </div>

      {/* ─── Main Footer ─── */}
      <footer
        ref={footerRef}
        className="relative overflow-hidden"
        style={{ background: 'linear-gradient(180deg, #080612 0%, #060410 40%, #050310 100%)' }}
      >
        {/* Background texture layers */}
        <div className="absolute inset-0 dot-grid opacity-20" />
        <div
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage: `
              linear-gradient(rgba(124,58,237,0.03) 1px, transparent 1px),
              linear-gradient(90deg, rgba(124,58,237,0.03) 1px, transparent 1px)
            `,
            backgroundSize: '80px 80px',
          }}
        />

        {/* Ambient violet glow — main */}
        <div
          className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[900px] h-[500px] rounded-full blur-[140px] pointer-events-none animate-orb-pulse"
          style={{ background: 'radial-gradient(circle, rgba(109,40,217,0.18) 0%, rgba(76,29,149,0.08) 50%, transparent 70%)' }}
        />
        {/* Secondary glow — left */}
        <div
          className="absolute top-1/3 -left-32 w-[400px] h-[400px] rounded-full blur-[100px] pointer-events-none opacity-40 animate-orb-drift"
          style={{ background: 'radial-gradient(circle, rgba(99,102,241,0.12) 0%, transparent 70%)' }}
        />
        {/* Secondary glow — right */}
        <div
          className="absolute top-1/4 -right-32 w-[300px] h-[300px] rounded-full blur-[80px] pointer-events-none opacity-30"
          style={{ background: 'radial-gradient(circle, rgba(139,92,246,0.12) 0%, transparent 70%)' }}
        />

        {/* Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-6 pt-20 pb-8">

          {/* ═══════════════════════════════════════════════════════════
              SECTION 1: Brand + Mission + Newsletter
          ═══════════════════════════════════════════════════════════ */}
          <div className="grid lg:grid-cols-5 gap-16 mb-16">

            {/* Brand Identity */}
            <div className={`lg:col-span-2 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
              {/* Logo */}
              <div className="flex items-center gap-3 mb-6">
                <div className="relative">
                  <div className="w-12 h-12 rounded-xl overflow-hidden relative flex items-center justify-center"
                    style={{ background: 'linear-gradient(135deg, #4c1d95 0%, #1e1b4b 100%)', border: '1px solid rgba(139,92,246,0.4)' }}>
                    <img src="/images/nexa-crystal.png" alt="NEXA-VAULT" className="w-8 h-8 object-contain animate-float-slow" />
                    <div className="absolute inset-0 rounded-xl"
                      style={{ boxShadow: 'inset 0 0 20px rgba(124,58,237,0.3)' }} />
                  </div>
                  {/* Glow ring */}
                  <div className="absolute -inset-1 rounded-xl opacity-50 animate-ping-slow"
                    style={{ border: '1px solid rgba(124,58,237,0.4)' }} />
                </div>
                <div>
                  <div className="font-display text-xl font-bold tracking-wider text-white">
                    NEXA<span className="text-violet-400">-</span>VAULT
                  </div>
                  <div className="text-[10px] text-slate-500 tracking-widest uppercase">Digital Rewards Platform</div>
                </div>
              </div>

              {/* Mission */}
              <p className="text-sm text-slate-400 leading-relaxed mb-6 max-w-xs">
                The premier destination for gaming top-ups and digital rewards. We're building the infrastructure that powers the next generation of digital gaming economies — securely, instantly, globally.
              </p>

              {/* System Status */}
              <div className="inline-flex items-center gap-2.5 px-4 py-2.5 rounded-lg border border-emerald-500/20 bg-emerald-500/5 mb-8">
                <div className="relative flex items-center justify-center">
                  <div className="w-2 h-2 rounded-full bg-emerald-400" />
                  <div className="absolute w-2 h-2 rounded-full bg-emerald-400 animate-ping-slow opacity-70" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-emerald-400">All Systems Operational</div>
                  <div className="text-[10px] text-slate-500">Last checked 42 seconds ago</div>
                </div>
              </div>

              {/* Social Links */}
              <div className="space-y-1">
                <p className="text-[10px] text-slate-600 tracking-widest uppercase mb-3">Follow the Vault</p>
                <div className="flex gap-2.5">
                  {SOCIAL_LINKS.map((s, i) => (
                    <a
                      key={i}
                      href="#"
                      onClick={(e) => e.preventDefault()}
                      title={`${s.label} — ${s.handle}`}
                      className="group w-9 h-9 rounded-lg border border-white/8 flex items-center justify-center transition-all duration-300 hover:scale-110 hover:-translate-y-0.5"
                      style={{ background: 'rgba(255,255,255,0.03)' }}
                      onMouseEnter={(e) => {
                        (e.currentTarget as HTMLAnchorElement).style.background = `${s.color}18`;
                        (e.currentTarget as HTMLAnchorElement).style.borderColor = `${s.color}50`;
                        (e.currentTarget as HTMLAnchorElement).style.boxShadow = `0 0 16px ${s.color}20`;
                      }}
                      onMouseLeave={(e) => {
                        (e.currentTarget as HTMLAnchorElement).style.background = 'rgba(255,255,255,0.03)';
                        (e.currentTarget as HTMLAnchorElement).style.borderColor = 'rgba(255,255,255,0.08)';
                        (e.currentTarget as HTMLAnchorElement).style.boxShadow = 'none';
                      }}
                    >
                      <span style={{ color: 'rgba(148,163,184,0.8)' }} className="group-hover:opacity-100 transition-colors">
                        {s.icon}
                      </span>
                    </a>
                  ))}
                </div>
              </div>
            </div>

            {/* Newsletter + Community Stats */}
            <div className={`lg:col-span-3 transition-all duration-700 delay-150 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>

              {/* Newsletter */}
              <div
                className="relative rounded-2xl p-6 mb-8 overflow-hidden"
                style={{
                  background: 'linear-gradient(135deg, rgba(124,58,237,0.08) 0%, rgba(99,102,241,0.05) 100%)',
                  border: '1px solid rgba(124,58,237,0.15)',
                }}
              >
                {/* Corner accent */}
                <div className="absolute top-0 right-0 w-32 h-32 rounded-bl-full opacity-20"
                  style={{ background: 'radial-gradient(circle at top right, rgba(124,58,237,0.6), transparent 70%)' }} />
                <div className="absolute top-0 left-0 right-0 h-px"
                  style={{ background: 'linear-gradient(90deg, transparent, rgba(124,58,237,0.6), transparent)' }} />

                <div className="relative">
                  <div className="flex items-start gap-3 mb-4">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-violet-500/15 border border-violet-500/20 flex-shrink-0">
                      <IconMail />
                    </div>
                    <div>
                      <h3 className="font-display text-sm font-semibold text-white">Vault Intelligence</h3>
                      <p className="text-xs text-slate-500 leading-relaxed mt-0.5">
                        Weekly drops: exclusive deals, early access, and platform updates. No noise, no spam.
                      </p>
                    </div>
                  </div>

                  {subscribed ? (
                    <div className="flex items-center gap-2 py-3 px-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                      <div className="w-4 h-4 text-emerald-400">
                        <IconShield />
                      </div>
                      <span className="text-xs text-emerald-300 font-medium">You're in the Vault. First drop incoming.</span>
                    </div>
                  ) : (
                    <form onSubmit={handleSubscribe} className="flex gap-2">
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Enter your email address"
                        className="flex-1 px-4 py-3 rounded-xl text-sm text-slate-200 placeholder-slate-600 outline-none transition-all duration-300 focus:border-violet-500/50"
                        style={{
                          background: 'rgba(255,255,255,0.04)',
                          border: '1px solid rgba(255,255,255,0.08)',
                        }}
                        onFocus={(e) => {
                          e.currentTarget.style.borderColor = 'rgba(124,58,237,0.5)';
                          e.currentTarget.style.background = 'rgba(124,58,237,0.06)';
                        }}
                        onBlur={(e) => {
                          e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)';
                          e.currentTarget.style.background = 'rgba(255,255,255,0.04)';
                        }}
                      />
                      <button
                        type="submit"
                        className="px-5 py-3 rounded-xl text-sm font-semibold text-white transition-all duration-300 hover:scale-105 flex-shrink-0"
                        style={{ background: 'linear-gradient(135deg, #7c3aed, #4f46e5)' }}
                      >
                        Join
                      </button>
                    </form>
                  )}
                </div>
              </div>

              {/* Community Stats */}
              <div className="grid grid-cols-3 gap-3">
                {[
                  { value: '12M+', label: 'Players Trust Us', icon: '🎮', color: 'rgba(124,58,237,0.12)', border: 'rgba(124,58,237,0.2)' },
                  { value: '4.9★', label: 'Platform Rating', icon: '⭐', color: 'rgba(251,191,36,0.08)', border: 'rgba(251,191,36,0.2)' },
                  { value: '180+', label: 'Games Supported', icon: '🏆', color: 'rgba(16,185,129,0.08)', border: 'rgba(16,185,129,0.2)' },
                ].map((stat, i) => (
                  <div
                    key={i}
                    className="rounded-xl p-4 text-center cursor-default group transition-all duration-300 hover:-translate-y-1"
                    style={{ background: stat.color, border: `1px solid ${stat.border}` }}
                  >
                    <div className="text-xl mb-1 group-hover:scale-110 transition-transform duration-300">{stat.icon}</div>
                    <div className="font-display text-lg font-bold text-white">{stat.value}</div>
                    <div className="text-[10px] text-slate-500">{stat.label}</div>
                  </div>
                ))}
              </div>

              {/* Support Quick Access */}
              <div
                className="mt-4 rounded-xl px-5 py-3.5 flex items-center justify-between cursor-pointer group transition-all duration-300 hover:border-violet-500/30"
                style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)' }}
                onClick={(e) => e.preventDefault()}
              >
                <div className="flex items-center gap-3">
                  <div className="text-violet-400"><IconSupport /></div>
                  <div>
                    <div className="text-xs font-semibold text-slate-300">Need help right now?</div>
                    <div className="text-[10px] text-slate-600">Live support — avg. response 2 min</div>
                  </div>
                </div>
                <div className="text-violet-400 group-hover:translate-x-1 transition-transform">
                  <IconArrow />
                </div>
              </div>
            </div>
          </div>

          {/* ═══════════════════════════════════════════════════════════
              SECTION 2: Trust & Compliance Bar
          ═══════════════════════════════════════════════════════════ */}
          <div className={`mb-14 transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div className="divider-glow mb-6" />
            <div className="flex items-center gap-3 mb-5">
              <div className="text-[10px] text-slate-600 tracking-widest uppercase">Security & Compliance</div>
              <div className="flex-1 h-px bg-white/5" />
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {TRUST_BADGES.map((badge, i) => (
                <TrustBadge key={i} {...badge} />
              ))}
            </div>

            {/* Compliance logos row */}
            <div className="mt-5 flex flex-wrap items-center gap-x-6 gap-y-3">
              {['PCI DSS', 'ISO 27001', 'GDPR', 'SOC 2 Type II', 'KYC/AML Verified'].map((cert, i) => (
                <div key={i} className="flex items-center gap-1.5">
                  <div className="w-3.5 h-3.5 text-violet-500">
                    <svg viewBox="0 0 24 24" fill="currentColor" className="w-3.5 h-3.5">
                      <path fillRule="evenodd" d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm13.36-1.814a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <span className="text-[10px] text-slate-500 font-medium">{cert}</span>
                </div>
              ))}
            </div>
          </div>

          {/* ═══════════════════════════════════════════════════════════
              SECTION 3: Navigation Columns
          ═══════════════════════════════════════════════════════════ */}
          <div className={`grid grid-cols-1 md:grid-cols-3 gap-10 mb-14 transition-all duration-700 delay-300 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>

            {/* Platform */}
            <div>
              <div className="flex items-center gap-2 mb-5">
                <div className="w-1 h-4 rounded-full bg-gradient-to-b from-violet-400 to-indigo-600" />
                <h4 className="text-xs font-semibold text-slate-300 tracking-wider uppercase">Platform</h4>
              </div>
              <ul className="space-y-0.5">
                {PLATFORM_LINKS.map((link, i) => (
                  <FooterLink key={i} label={link.label} badge={link.badge} />
                ))}
              </ul>
            </div>

            {/* Support */}
            <div>
              <div className="flex items-center gap-2 mb-5">
                <div className="w-1 h-4 rounded-full bg-gradient-to-b from-emerald-400 to-cyan-600" />
                <h4 className="text-xs font-semibold text-slate-300 tracking-wider uppercase">Support</h4>
              </div>
              <ul className="space-y-0.5">
                {SUPPORT_LINKS.map((link, i) => (
                  <FooterLink key={i} label={link.label} badge={link.badge} />
                ))}
              </ul>
            </div>

            {/* Company */}
            <div>
              <div className="flex items-center gap-2 mb-5">
                <div className="w-1 h-4 rounded-full bg-gradient-to-b from-amber-400 to-orange-600" />
                <h4 className="text-xs font-semibold text-slate-300 tracking-wider uppercase">Company</h4>
              </div>
              <ul className="space-y-0.5">
                {COMPANY_LINKS.map((link, i) => (
                  <FooterLink key={i} label={link.label} badge={link.badge} />
                ))}
              </ul>
            </div>
          </div>

          {/* ═══════════════════════════════════════════════════════════
              SECTION 4: Payment Methods
          ═══════════════════════════════════════════════════════════ */}
          <div className={`mb-14 transition-all duration-700 delay-400 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div className="divider-glow mb-8" />
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
              <div>
                <div className="text-[10px] text-slate-600 tracking-widest uppercase mb-3">Accepted Payment Methods</div>
                <div className="flex flex-wrap gap-2">
                  {PAYMENT_METHODS.map((method, i) => (
                    <div
                      key={i}
                      className="px-3 py-1.5 rounded-lg text-xs text-slate-400 font-medium transition-all duration-200 hover:text-slate-200 cursor-default"
                      style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}
                    >
                      {method}
                    </div>
                  ))}
                </div>
              </div>

              {/* Platform Version + Uptime */}
              <div className="flex flex-col items-end gap-2">
                <div className="flex items-center gap-3">
                  <div
                    className="px-3 py-1 rounded-md text-[10px] font-mono text-slate-500"
                    style={{ background: 'rgba(124,58,237,0.08)', border: '1px solid rgba(124,58,237,0.15)' }}
                  >
                    v3.12.0-stable
                  </div>
                  <div
                    className="px-3 py-1 rounded-md text-[10px] font-semibold text-emerald-300"
                    style={{ background: 'rgba(16,185,129,0.08)', border: '1px solid rgba(16,185,129,0.2)' }}
                  >
                    99.97% uptime / 30d
                  </div>
                </div>
                <div className="text-[10px] text-slate-600">Platform health monitored 24/7 by our NOC team</div>
              </div>
            </div>
          </div>

          {/* ═══════════════════════════════════════════════════════════
              SECTION 5: Vision Statement — Signature Quote
          ═══════════════════════════════════════════════════════════ */}
          <div className={`mb-14 transition-all duration-700 delay-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div
              className="relative rounded-2xl p-8 overflow-hidden text-center"
              style={{
                background: 'linear-gradient(135deg, rgba(124,58,237,0.06) 0%, rgba(79,70,229,0.04) 50%, rgba(109,40,217,0.06) 100%)',
                border: '1px solid rgba(124,58,237,0.12)',
              }}
            >
              {/* Corner brackets */}
              <div className="absolute top-4 left-4 w-6 h-6 border-l border-t border-violet-500/30" />
              <div className="absolute top-4 right-4 w-6 h-6 border-r border-t border-violet-500/30" />
              <div className="absolute bottom-4 left-4 w-6 h-6 border-l border-b border-violet-500/30" />
              <div className="absolute bottom-4 right-4 w-6 h-6 border-r border-b border-violet-500/30" />

              {/* Glow top */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-px"
                style={{ background: 'linear-gradient(90deg, transparent, rgba(124,58,237,0.8), transparent)' }} />

              <div className="relative">
                <div className="text-2xl mb-3 opacity-30 text-violet-300 font-display">"</div>
                <p className="font-display text-lg md:text-xl font-medium text-slate-300 leading-relaxed max-w-2xl mx-auto mb-3">
                  We are building the financial layer of gaming —<br className="hidden md:block" />
                  <span className="text-gradient-violet">where every player's digital life is secure, rewarded, and valued.</span>
                </p>
                <div className="text-[11px] text-slate-600 tracking-wider">— The NEXA-VAULT founding team</div>
              </div>
            </div>
          </div>

          {/* ═══════════════════════════════════════════════════════════
              SECTION 6: Legal Footer Strip
          ═══════════════════════════════════════════════════════════ */}
          <div className={`transition-all duration-700 delay-[600ms] ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div className="h-px mb-6"
              style={{ background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.06) 30%, rgba(255,255,255,0.06) 70%, transparent 100%)' }} />

            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              {/* Copyright */}
              <div className="flex flex-col items-center md:items-start gap-1">
                <div className="flex items-center gap-2">
                  <div className="font-display text-xs font-bold text-slate-500 tracking-wider">NEXA-VAULT</div>
                  <span className="text-slate-700 text-xs">©</span>
                  <span className="text-slate-600 text-xs">2025</span>
                  <span className="text-slate-700">·</span>
                  <span className="text-slate-600 text-xs">All rights reserved.</span>
                </div>
                <p className="text-[10px] text-slate-700 max-w-xs text-center md:text-left">
                  NEXA-VAULT is not affiliated with any game publisher. All trademarks belong to their respective owners.
                </p>
              </div>

              {/* Legal Links */}
              <div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2">
                {LEGAL_LINKS.map((link, i) => (
                  <a
                    key={i}
                    href="#"
                    onClick={(e) => e.preventDefault()}
                    className="text-[11px] text-slate-600 hover:text-slate-400 transition-colors duration-200"
                  >
                    {link}
                  </a>
                ))}
              </div>

              {/* Region selector */}
              <div
                className="flex items-center gap-2 px-3 py-2 rounded-lg cursor-default text-slate-500 hover:text-slate-400 transition-colors"
                style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}
              >
                <IconGlobe />
                <span className="text-xs">Global — EN</span>
              </div>
            </div>
          </div>

          {/* ═══════════════════════════════════════════════════════════
              SECTION 7: Signature bottom inscription
          ═══════════════════════════════════════════════════════════ */}
          <div className="mt-16 mb-0 relative">
            {/* Giant faded wordmark */}
            <div className="relative overflow-hidden h-16">
              <div
                className="absolute inset-0 flex items-center justify-center font-display font-black text-[80px] tracking-[0.25em] select-none pointer-events-none"
                style={{
                  background: 'linear-gradient(180deg, rgba(124,58,237,0.06) 0%, transparent 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                }}
              >
                NEXA-VAULT
              </div>
            </div>

            {/* Bottom glow line */}
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-64 h-px"
              style={{ background: 'linear-gradient(90deg, transparent, rgba(124,58,237,0.5), transparent)' }} />
          </div>
        </div>
      </footer>
    </>
  );
}
