import { useState, useEffect } from 'react';

const STATS = [
  { value: '12M+', label: 'Active Players' },
  { value: '$2.4B', label: 'Rewards Delivered' },
  { value: '180+', label: 'Game Titles' },
  { value: '99.9%', label: 'Uptime SLA' },
];

const GAMES = [
  { name: 'VALORANT', tag: 'FPS', color: 'from-red-500/20 to-rose-900/10', accent: '#ef4444', points: '500 VP' },
  { name: 'FORTNITE', tag: 'Battle Royale', color: 'from-blue-500/20 to-indigo-900/10', accent: '#3b82f6', points: '1000 V-Bucks' },
  { name: 'APEX LEGENDS', tag: 'BR / Hero', color: 'from-orange-500/20 to-amber-900/10', accent: '#f97316', points: '2150 Coins' },
  { name: 'GENSHIN IMPACT', tag: 'RPG', color: 'from-violet-500/20 to-purple-900/10', accent: '#8b5cf6', points: '160 Primogems' },
  { name: 'LEAGUE OF LEGENDS', tag: 'MOBA', color: 'from-cyan-500/20 to-sky-900/10', accent: '#06b6d4', points: '1380 RP' },
  { name: 'FREE FIRE', tag: 'Mobile BR', color: 'from-emerald-500/20 to-green-900/10', accent: '#10b981', points: '520 Diamonds' },
];

const FEATURES = [
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-6 h-6">
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" />
      </svg>
    ),
    title: 'Instant Delivery',
    desc: 'Credits and rewards delivered in under 60 seconds. Always.',
    accent: 'text-amber-400',
    glow: 'shadow-amber-500/20',
  },
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-6 h-6">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.955 11.955 0 003 12c0 6.627 5.373 12 12 12s12-5.373 12-12c0-2.128-.556-4.124-1.534-5.855M12 2.25c.657 0 1.302.055 1.93.162" />
      </svg>
    ),
    title: 'Military-Grade Security',
    desc: 'AES-256 encryption on every transaction. Zero compromise.',
    accent: 'text-violet-400',
    glow: 'shadow-violet-500/20',
  },
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5} className="w-6 h-6">
        <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 18.75h-9m9 0a3 3 0 013 3h-15a3 3 0 013-3m9 0v-3.375c0-.621-.503-1.125-1.125-1.125h-.871M7.5 18.75v-3.375c0-.621.504-1.125 1.125-1.125h.872m5.007 0H9.497m5.007 0a7.454 7.454 0 01-.982-3.172M9.497 14.25a7.454 7.454 0 00.981-3.172M5.25 4.236c-.982.143-1.954.317-2.916.52A6.003 6.003 0 007.73 9.728M5.25 4.236V4.5c0 2.108.966 3.99 2.48 5.228M5.25 4.236V2.721C7.456 2.41 9.71 2.25 12 2.25c2.291 0 4.545.16 6.75.47v1.516M7.73 9.728a6.726 6.726 0 002.748 1.35m8.272-6.842V4.5c0 2.108-.966 3.99-2.48 5.228m2.48-5.492a46.32 46.32 0 012.916.52 6.003 6.003 0 01-5.395 4.972m0 0a6.726 6.726 0 01-2.749 1.35m0 0a6.772 6.772 0 01-3.044 0" />
      </svg>
    ),
    title: 'NEXA Rewards',
    desc: 'Earn NEXA Points on every top-up. Redeem for bonuses, exclusives, and cashback.',
    accent: 'text-cyan-400',
    glow: 'shadow-cyan-500/20',
  },
];

export default function MockPage() {
  const [scrolled, setScrolled] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="bg-[#07060f] overflow-hidden">
      {/* ─── HERO ─── */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background grid */}
        <div className="absolute inset-0 dot-grid opacity-40" />

        {/* Ambient orbs */}
        <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] rounded-full bg-violet-900/20 blur-[120px] animate-orb-pulse" />
        <div className="absolute bottom-1/4 right-1/3 w-[400px] h-[400px] rounded-full bg-indigo-900/15 blur-[100px] animate-orb-drift" />
        <div className="absolute top-1/2 right-1/4 w-[300px] h-[300px] rounded-full bg-purple-900/20 blur-[80px] animate-orb-pulse" style={{ animationDelay: '2s' }} />

        {/* Scan line effect */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div
            className="absolute left-0 right-0 h-px"
            style={{
              background: 'linear-gradient(90deg, transparent, rgba(124,58,237,0.4), transparent)',
              top: `${(scrolled * 0.3) % 100}%`,
            }}
          />
        </div>

        {/* Corner decorations */}
        <div className="absolute top-8 left-8 w-16 h-16 border-l-2 border-t-2 border-violet-500/30 rounded-tl-lg" />
        <div className="absolute top-8 right-8 w-16 h-16 border-r-2 border-t-2 border-violet-500/30 rounded-tr-lg" />
        <div className="absolute bottom-8 left-8 w-16 h-16 border-l-2 border-b-2 border-violet-500/30 rounded-bl-lg" />
        <div className="absolute bottom-8 right-8 w-16 h-16 border-r-2 border-b-2 border-violet-500/30 rounded-br-lg" />

        <div className="relative z-10 text-center max-w-5xl mx-auto px-6">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-violet-500/30 bg-violet-500/10 mb-8 backdrop-blur-sm">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping-slow" />
            <span className="text-xs font-medium text-violet-300 tracking-widest uppercase">Platform Live — 12M+ Players Online</span>
          </div>

          {/* Headline */}
          <h1 className="font-display text-6xl md:text-8xl font-bold leading-[0.9] tracking-tight mb-6">
            <span className="text-white">POWER UP</span>
            <br />
            <span className="text-shimmer">YOUR GAME</span>
          </h1>

          <p className="text-lg text-slate-400 max-w-xl mx-auto mb-10 leading-relaxed">
            Instant top-ups, exclusive digital rewards, and a secure vault for everything you've earned. Built for serious players.
          </p>

          <div className="flex items-center justify-center gap-4 flex-wrap">
            <button className="group relative px-8 py-4 rounded-xl overflow-hidden font-semibold text-white text-sm tracking-wide transition-all duration-300 hover:scale-105">
              <div className="absolute inset-0 bg-gradient-to-r from-violet-600 to-indigo-600 group-hover:from-violet-500 group-hover:to-indigo-500 transition-all duration-300" />
              <div className="absolute inset-0 animate-glow-pulse opacity-0 group-hover:opacity-100" />
              <span className="relative z-10 flex items-center gap-2">
                Start Top-Up
                <svg className="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
                </svg>
              </span>
            </button>
            <button className="px-8 py-4 rounded-xl border border-violet-500/30 text-violet-300 text-sm font-medium hover:bg-violet-500/10 hover:border-violet-500/50 transition-all duration-300">
              Explore Vault
            </button>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-50">
          <span className="text-xs text-slate-500 tracking-widest uppercase">Scroll</span>
          <div className="w-px h-12 bg-gradient-to-b from-violet-500/60 to-transparent" />
        </div>
      </section>

      {/* ─── STATS BAR ─── */}
      <section className="relative py-8 border-y border-violet-500/10">
        <div className="absolute inset-0 bg-gradient-to-r from-violet-950/20 via-indigo-950/20 to-violet-950/20" />
        <div className="relative max-w-6xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {STATS.map((stat, i) => (
              <div key={i} className="text-center">
                <div className="font-display text-3xl font-bold text-gradient-violet mb-1">{stat.value}</div>
                <div className="text-xs text-slate-500 tracking-wider uppercase">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── FEATURES ─── */}
      <section className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-xs text-violet-400 tracking-widest uppercase mb-3">Platform Core</p>
            <h2 className="font-display text-4xl font-bold text-white">
              Built for the <span className="text-gradient-violet">Elite Player</span>
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {FEATURES.map((feat, i) => (
              <div key={i} className={`glass-card glass-card-hover rounded-2xl p-8 group cursor-default shadow-lg ${feat.glow}`}>
                <div className={`${feat.accent} mb-5 group-hover:scale-110 transition-transform`}>
                  {feat.icon}
                </div>
                <h3 className="font-display text-lg font-semibold text-white mb-3">{feat.title}</h3>
                <p className="text-sm text-slate-400 leading-relaxed">{feat.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── GAMES GRID ─── */}
      <section className="py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-end justify-between mb-10">
            <div>
              <p className="text-xs text-violet-400 tracking-widest uppercase mb-2">Top-Up Available For</p>
              <h2 className="font-display text-3xl font-bold text-white">Popular Games</h2>
            </div>
            <button className="text-sm text-violet-400 hover:text-violet-300 transition-colors flex items-center gap-1">
              View all 180+
              <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
              </svg>
            </button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {GAMES.map((game, i) => (
              <div
                key={i}
                className={`relative glass-card rounded-xl p-5 cursor-pointer group overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:border-white/10`}
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${game.color} opacity-60 group-hover:opacity-100 transition-opacity`} />
                <div className="relative z-10">
                  <div className="flex items-start justify-between mb-6">
                    <span className="text-xs font-medium px-2 py-1 rounded-full border text-slate-400 border-white/10">{game.tag}</span>
                    <div className="w-2 h-2 rounded-full" style={{ background: game.accent, boxShadow: `0 0 8px ${game.accent}` }} />
                  </div>
                  <div className="font-display text-sm font-bold text-white tracking-wider mb-1">{game.name}</div>
                  <div className="text-xs" style={{ color: game.accent }}>{game.points}</div>
                </div>
                <div
                  className="absolute bottom-0 right-0 w-24 h-24 rounded-full blur-3xl opacity-20 group-hover:opacity-40 transition-opacity"
                  style={{ background: game.accent }}
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── PRE-FOOTER CTA ─── */}
      <section className="py-24 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-violet-950/10 to-transparent" />
        <div className="relative max-w-3xl mx-auto text-center glass-card rounded-3xl p-16 border-neon">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-px w-48 h-px bg-gradient-to-r from-transparent via-violet-400 to-transparent" />
          <p className="text-xs text-violet-400 tracking-widest uppercase mb-4">Join the Vault</p>
          <h2 className="font-display text-4xl font-bold text-white mb-4">Ready to Level Up?</h2>
          <p className="text-slate-400 mb-8 leading-relaxed">
            Create your NEXA-VAULT account today and get 200 bonus NEXA Points on your first top-up.
          </p>
          <button className="group relative px-10 py-4 rounded-xl overflow-hidden font-semibold text-white text-sm tracking-wide transition-all duration-300 hover:scale-105 animate-glow-pulse">
            <div className="absolute inset-0 bg-gradient-to-r from-violet-600 to-indigo-600 group-hover:from-violet-500 group-hover:to-indigo-500 transition-all duration-300" />
            <span className="relative z-10">Create Free Account</span>
          </button>
        </div>
      </section>
    </div>
  );
}
