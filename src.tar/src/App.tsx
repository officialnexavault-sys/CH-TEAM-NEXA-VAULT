import MockPage from './components/MockPage';
import Footer from './components/Footer';

export default function App() {
  return (
    <div style={{ fontFamily: "'Inter', sans-serif" }}>
      <MockPage />
      <Footer />
    </div>
  );
}
